# video-call-app-mern
Preview: ----> https://ad-video-call-app-mern.netlify.app/

## Introduction
In this Project, we're build a React Video Chat Application using WebRTC (Socket.io , Socket.io-client , peer , simple-peer , cors etc...).

Setup:
- run ```npm i && npm start``` for both client and server side to start the development server
